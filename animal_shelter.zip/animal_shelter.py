from pymongo import MongoClient

class AnimalShelter:
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self, user="aacuser", password="NewSecurePassword",
                 host="nv-desktop-services.apporto.com", port=30444, db="AAC", col="animals"):
        """
        Initializes the connection to the MongoDB database.
        """
        try:
            self.client = MongoClient(
                f'mongodb://{user}:{password}@{host}:{port}/?authSource=admin',
                serverSelectionTimeoutMS=5000  # 5-second timeout for quick failure detection
            )
            self.database = self.client[db]
            self.collection = self.database[col]
            print("MongoDB Connection Successful!")
        except Exception as e:
            print(f"Error connecting to MongoDB: {e}")

    def create(self, data):
        """
        Inserts a document into the database.
        :param data: A dictionary containing the document to insert.
        :return: True if insert successful, else False.
        """
        if data:
            try:
                result = self.collection.insert_one(data)
                return True if result.inserted_id else False
            except Exception as e:
                print(f"Error inserting data: {e}")
                return False
        else:a
            raise ValueError("Nothing to save, data parameter is empty")

    def read(self, query):
        """
        Queries documents from the database.
        :param query: A dictionary specifying the search criteria.
        :return: A list of matching documents.
        """
        try:
            results = list(self.collection.find(query))
            return results if results else []
        except Exception as e:
            print(f"Error reading from MongoDB: {e}")
            return []
